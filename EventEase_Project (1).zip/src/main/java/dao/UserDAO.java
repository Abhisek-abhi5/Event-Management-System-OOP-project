package dao;

import model.Admin;
import model.Client;
import model.User;

import java.sql.*;

public class UserDAO {
    public static User login(String email, String password) {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT * FROM users WHERE email = ? AND password = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, email);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                String role = rs.getString("role");

                if (role.equals("Admin")) {
                    return new Admin(id, name, email);
                } else if (role.equals("Client")) {
                    return new Client(id, name, email);
                }
            }
        } catch (SQLException e) {
            System.out.println("Login error: " + e.getMessage());
        }
        return null;
    }
}