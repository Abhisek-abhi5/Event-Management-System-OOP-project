package gui;

import dao.UserDAO;
import model.User;

import javax.swing.*;

public class LoginPage extends JFrame {
    JTextField emailField;
    JPasswordField passwordField;

    public LoginPage() {
        setTitle("EventEase Login");
        setSize(300, 180);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        emailField = new JTextField(15);
        passwordField = new JPasswordField(15);

        JButton loginBtn = new JButton("Login");
        loginBtn.addActionListener(e -> login());

        JPanel panel = new JPanel();
        panel.add(new JLabel("Email:"));
        panel.add(emailField);
        panel.add(new JLabel("Password:"));
        panel.add(passwordField);
        panel.add(loginBtn);

        add(panel);
        setVisible(true);
    }

    private void login() {
        String email = emailField.getText();
        String password = new String(passwordField.getPassword());

        User user = UserDAO.login(email, password);
        if (user != null) {
            JOptionPane.showMessageDialog(this, "Welcome, " + user.getRole() + " " + user.name + "!");
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Login failed. Check credentials.");
        }
    }

    public static void main(String[] args) {
        new LoginPage();
    }
}