CREATE DATABASE IF NOT EXISTS eventease;
USE eventease;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100) UNIQUE,
    password VARCHAR(100),
    role ENUM('Admin', 'Client') NOT NULL
);

INSERT INTO users (name, email, password, role) VALUES
('Alice Admin', 'admin@example.com', 'admin123', 'Admin'),
('Bob Client', 'client@example.com', 'client123', 'Client');